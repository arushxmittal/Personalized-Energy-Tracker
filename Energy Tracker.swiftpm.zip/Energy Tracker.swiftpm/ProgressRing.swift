import SwiftUI

struct ProgressRing: View {
    
    var score: Double
    
    var body: some View {
        ZStack {
            Circle()
                .stroke(Color.white.opacity(0.2), lineWidth: 20)
            
            Circle()
                .trim(from: 0, to: score / 100)
                .stroke(.green,
                        style: StrokeStyle(lineWidth: 20,
                                           lineCap: .round))
                .rotationEffect(.degrees(-90))
            
            Text("\(Int(score))%")
                .font(.largeTitle.bold())
        }
        .frame(width: 200, height: 200)
    }
}
