import SwiftUI

struct EnergyRoute: Hashable {
    let userName: String
    let sleep: Double
    let stress: Double
    let focus: Double
    let mood: Double
    let score: Double
}

struct InputView: View {

    let userName: String
    @Binding var path: NavigationPath
    @StateObject private var store = EnergyStore()

    @State private var sleep = 7.0
    @State private var stress = 5.0
    @State private var focus = 6.0
    @State private var mood = 7.0

    var body: some View {
        ZStack {
            background

            VStack(spacing: 25) {

                Text("Hi, \(userName)")
                    .font(.title.bold())
                    .foregroundColor(.white)

                sliderRow("Sleep", icon: "bed.double.fill", value: $sleep)
                sliderRow("Stress", icon: "flame.fill", value: $stress)
                sliderRow("Focus", icon: "target", value: $focus)
                sliderRow("Mood", icon: "face.smiling.fill", value: $mood)

                Button("Analyze Energy") {
                    analyze()
                }
                .frame(maxWidth: .infinity)
                .padding()
                .background(
                    LinearGradient(
                        colors: [.purple, .blue],
                        startPoint: .leading,
                        endPoint: .trailing
                    )
                )
                .cornerRadius(16)
                .foregroundColor(.white)
            }
            .padding()
        }
        .navigationBarTitleDisplayMode(.inline)
        .navigationDestination(for: EnergyRoute.self) { route in
            ResultView(
                userName: route.userName,
                sleep: route.sleep,
                stress: route.stress,
                focus: route.focus,
                mood: route.mood,
                score: route.score,
                store: store,
                path: $path
            )
        }
    }

    func analyze() {
        let score = EnergyCalculator.calculate(
            sleep: sleep,
            stress: stress,
            focus: focus,
            mood: mood
        )

        let entry = EnergyEntry(
            date: Date(),
            sleep: sleep,
            stress: stress,
            focus: focus,
            mood: mood,
            score: score
        )

        store.add(entry: entry)

        path.append(EnergyRoute(
            userName: userName,
            sleep: sleep,
            stress: stress,
            focus: focus,
            mood: mood,
            score: score
        ))
    }

    func sliderRow(_ title: String,
                   icon: String,
                   value: Binding<Double>) -> some View {
        VStack(alignment: .leading) {
            HStack {
                Label(title, systemImage: icon)
                    .foregroundColor(.white)
                Spacer()
                Text("\(Int(value.wrappedValue))")
                    .foregroundColor(.white.opacity(0.8))
                    .bold()
            }
            Slider(value: value, in: 1...10, step: 1)
                .tint(.purple)
        }
    }

    var background: some View {
        LinearGradient(
            colors: [Color.black,
                     Color.purple.opacity(0.7),
                     Color.blue.opacity(0.6)],
            startPoint: .topLeading,
            endPoint: .bottomTrailing
        )
        .ignoresSafeArea()
    }
}
