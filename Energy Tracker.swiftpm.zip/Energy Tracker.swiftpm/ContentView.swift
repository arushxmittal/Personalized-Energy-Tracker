import SwiftUI
import UIKit

struct ContentView: View {
    
    @StateObject private var store = EnergyStore()
    
    @State private var sleep = 7.0
    @State private var stress = 5.0
    @State private var focus = 6.0
    @State private var mood = 7.0
    
    @State private var score: Double?
    
    var body: some View {
        ZStack {
            
            LinearGradient(
                colors: [
                    Color.black,
                    Color.purple.opacity(0.8),
                    Color.blue.opacity(0.7)
                ],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            .ignoresSafeArea()
            
            ScrollView {
                VStack(spacing: 28) {
                    
                    header
                    
                    inputSection
                    
                    analyzeButton
                    
                    if let score = score {
                        resultSection(score: score)
                    }
                }
                .padding()
            }
        }
    }
}

extension ContentView {
    
    var header: some View {
        VStack(spacing: 6) {
            Text("Pulse")
                .font(.system(size: 42, weight: .bold))
                .foregroundColor(.white)
            
            Text("Your Energy Mirror")
                .font(.subheadline)
                .foregroundColor(.white.opacity(0.7))
        }
    }
    
    var inputSection: some View {
        VStack(spacing: 18) {
            sliderRow(title: "Sleep", icon: "bed.double.fill", value: $sleep)
            sliderRow(title: "Stress", icon: "flame.fill", value: $stress)
            sliderRow(title: "Focus", icon: "target", value: $focus)
            sliderRow(title: "Mood", icon: "face.smiling.fill", value: $mood)
        }
        .glassCard()
    }
    
    var analyzeButton: some View {
        Button(action: analyze) {
            Text("Analyze Energy")
                .font(.headline)
                .frame(maxWidth: .infinity)
                .padding()
                .background(
                    LinearGradient(
                        colors: [.purple, .blue],
                        startPoint: .leading,
                        endPoint: .trailing
                    )
                )
                .cornerRadius(16)
                .foregroundColor(.white)
                .shadow(color: .purple.opacity(0.6), radius: 10)
        }
    }
    
    func resultSection(score: Double) -> some View {
        VStack(spacing: 22) {
            
            ProgressRing(score: score)
            
            energyStatusLabel(score)
            
            VStack(alignment: .leading, spacing: 10) {
                
                Text("SMART SUGGESTION")
                    .font(.caption)
                    .foregroundColor(.purple)
                
                Text(EnergyCalculator.suggestion(for: score))
                    .foregroundColor(.white.opacity(0.85))
            }
            .padding()
            .glassCard()
            
            VStack(alignment: .leading, spacing: 8) {
                
                Text("INSIGHT")
                    .font(.caption)
                    .foregroundColor(.purple)
                
                Text(generateSimpleInsight())
                    .foregroundColor(.white.opacity(0.85))
            }
            .padding()
            .glassCard()
            
            EnergyChartView(entries: store.entries)
        }
        .animation(.spring(), value: score)
    }
    
    func sliderRow(title: String,
                   icon: String,
                   value: Binding<Double>) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            
            HStack {
                Label(title, systemImage: icon)
                    .foregroundColor(.white)
                
                Spacer()
                
                Text("\(Int(value.wrappedValue))")
                    .foregroundColor(.white.opacity(0.8))
                    .bold()
            }
            
            Slider(value: value,
                   in: 1...10,
                   step: 1)
                .tint(.purple)
        }
    }
    
    func analyze() {
        
        let newScore = EnergyCalculator.calculate(
            sleep: sleep,
            stress: stress,
            focus: focus,
            mood: mood
        )
        
        score = newScore
        
        let entry = EnergyEntry(
            date: Date(),
            sleep: sleep,
            stress: stress,
            focus: focus,
            mood: mood,
            score: newScore
        )
        
        store.add(entry: entry)
        
        let generator = UINotificationFeedbackGenerator()
        generator.notificationOccurred(.success)
    }
    
    func energyStatusLabel(_ score: Double) -> some View {
        
        let text: String
        let color: Color
        
        if score >= 70 {
            text = "HIGH ENERGY"
            color = .green
        } else if score >= 40 {
            text = "MODERATE ENERGY"
            color = .yellow
        } else {
            text = "LOW ENERGY — REST UP"
            color = .red
        }
        
        return Text(text)
            .font(.caption)
            .padding(.horizontal, 16)
            .padding(.vertical, 6)
            .background(color.opacity(0.2))
            .foregroundColor(color)
            .cornerRadius(20)
    }
    
    func generateSimpleInsight() -> String {
        
        if sleep < 5 {
            return "You might feel better with more sleep."
        }
        
        if stress > 7 {
            return "High stress is likely lowering your energy."
        }
        
        if focus > 8 {
            return "Your focus is one of your biggest strengths."
        }
        
        if mood < 4 {
            return "Improving your mood could boost your energy."
        }
        
        return "Your energy looks fairly balanced today."
    }
}
