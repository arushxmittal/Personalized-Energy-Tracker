import SwiftUI

@main
struct PulseApp: App {

    @State private var path = NavigationPath()

    var body: some Scene {
        WindowGroup {
            NavigationStack(path: $path) {
                LoginView(path: $path)
            }
            .preferredColorScheme(.dark)
        }
    }
}
