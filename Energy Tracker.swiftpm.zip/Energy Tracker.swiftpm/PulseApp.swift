import SwiftUI

@main
struct PulseApp: App {
    var body: some Scene {
        WindowGroup {
            NavigationStack {
                LoginView()
            }
            .preferredColorScheme(.dark)
        }
    }
}
