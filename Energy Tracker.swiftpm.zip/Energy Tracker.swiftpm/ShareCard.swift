import SwiftUI

struct ShareCardView: View {
    
    let userName: String
    let sleep: Double
    let stress: Double
    let focus: Double
    let mood: Double
    let score: Double
    
    @Environment(\.dismiss) private var dismiss
    @State private var showShareSheet = false
    @State private var renderedImage: UIImage? = nil
    
    var body: some View {
        ZStack {
            Color.black.opacity(0.85).ignoresSafeArea()
            
            VStack(spacing: 24) {
                
                // Top bar
                HStack {
                    Button(action: { dismiss() }) {
                        Image(systemName: "xmark.circle.fill")
                            .font(.title2)
                            .foregroundColor(.white.opacity(0.6))
                    }
                    Spacer()
                    Text("Share Your Energy")
                        .font(.headline)
                        .foregroundColor(.white)
                    Spacer()
                    // Balance
                    Image(systemName: "xmark.circle.fill")
                        .font(.title2)
                        .foregroundColor(.clear)
                }
                .padding(.horizontal)
                .padding(.top, 8)
                
                // The card itself
                shareCard
                    .padding(.horizontal, 20)
                
                // Share button
                Button(action: {
                    renderedImage = renderCard()
                    showShareSheet = true
                }) {
                    HStack(spacing: 10) {
                        Image(systemName: "square.and.arrow.up")
                            .font(.subheadline.bold())
                        Text("Share Card")
                            .font(.headline)
                    }
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(
                        LinearGradient(
                            colors: [.purple, .blue],
                            startPoint: .leading,
                            endPoint: .trailing
                        )
                    )
                    .foregroundColor(.white)
                    .cornerRadius(16)
                    .shadow(color: .purple.opacity(0.5), radius: 10)
                }
                .padding(.horizontal, 20)
                .padding(.bottom, 20)
            }
        }
        .sheet(isPresented: $showShareSheet) {
            if let image = renderedImage {
                ShareSheet(items: [image])
            }
        }
    }
    
    // MARK: - The visual share card
    var shareCard: some View {
        VStack(spacing: 0) {
            
            // Header
            VStack(spacing: 6) {
                Text("⚡ Pulse Energy Report")
                    .font(.caption)
                    .fontWeight(.semibold)
                    .foregroundColor(.white.opacity(0.6))
                    .padding(.top, 20)
                
                Text(userName)
                    .font(.title.bold())
                    .foregroundColor(.white)
                
                Text(formattedDate)
                    .font(.caption)
                    .foregroundColor(.white.opacity(0.5))
            }
            
            Divider()
                .background(Color.white.opacity(0.1))
                .padding(.vertical, 16)
                .padding(.horizontal, 24)
            
            // Score ring + label
            ZStack {
                Circle()
                    .stroke(Color.white.opacity(0.15), lineWidth: 14)
                    .frame(width: 130, height: 130)
                
                Circle()
                    .trim(from: 0, to: score / 100)
                    .stroke(
                        scoreColor,
                        style: StrokeStyle(lineWidth: 14, lineCap: .round)
                    )
                    .rotationEffect(.degrees(-90))
                    .frame(width: 130, height: 130)
                
                VStack(spacing: 2) {
                    Text("\(Int(score))%")
                        .font(.system(size: 28, weight: .bold))
                        .foregroundColor(.white)
                    Text(scoreLabel)
                        .font(.caption2)
                        .foregroundColor(scoreColor)
                        .fontWeight(.semibold)
                }
            }
            .padding(.bottom, 20)
            
            // Stats row
            HStack(spacing: 0) {
                shareStatItem(icon: "bed.double.fill", label: "Sleep",  value: sleep,  color: .blue)
                Divider().background(Color.white.opacity(0.1)).frame(height: 40)
                shareStatItem(icon: "flame.fill",      label: "Stress", value: stress, color: .orange)
                Divider().background(Color.white.opacity(0.1)).frame(height: 40)
                shareStatItem(icon: "target",          label: "Focus",  value: focus,  color: .cyan)
                Divider().background(Color.white.opacity(0.1)).frame(height: 40)
                shareStatItem(icon: "face.smiling.fill", label: "Mood", value: mood,   color: .pink)
            }
            .padding(.horizontal, 10)
            .padding(.bottom, 16)
            
            Divider()
                .background(Color.white.opacity(0.1))
                .padding(.horizontal, 24)
            
            // Suggestion
            Text(EnergyCalculator.suggestion(for: score))
                .font(.caption)
                .foregroundColor(.white.opacity(0.75))
                .multilineTextAlignment(.center)
                .padding(.horizontal, 20)
                .padding(.vertical, 14)
            
            // Footer
            Text("Tracked with Pulse ⚡")
                .font(.caption2)
                .foregroundColor(.white.opacity(0.3))
                .padding(.bottom, 18)
        }
        .background(
            ZStack {
                LinearGradient(
                    colors: [Color(red: 0.08, green: 0.0, blue: 0.18),
                             Color(red: 0.0, green: 0.05, blue: 0.25)],
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                )
                // Subtle glow
                Circle()
                    .fill(scoreColor.opacity(0.12))
                    .frame(width: 200, height: 200)
                    .offset(x: 60, y: -40)
                    .blur(radius: 40)
            }
        )
        .cornerRadius(28)
        .overlay(
            RoundedRectangle(cornerRadius: 28)
                .stroke(scoreColor.opacity(0.3), lineWidth: 1)
        )
        .shadow(color: scoreColor.opacity(0.25), radius: 20)
    }
    
    func shareStatItem(icon: String, label: String, value: Double, color: Color) -> some View {
        VStack(spacing: 4) {
            Image(systemName: icon)
                .foregroundColor(color)
                .font(.subheadline)
            Text("\(Int(value))")
                .font(.system(size: 18, weight: .bold))
                .foregroundColor(.white)
            Text(label)
                .font(.caption2)
                .foregroundColor(.white.opacity(0.5))
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 12)
    }
    
    // MARK: - Helpers
    private var scoreColor: Color {
        if score >= 70 { return .green }
        if score >= 40 { return .yellow }
        return .red
    }
    
    private var scoreLabel: String {
        if score >= 70 { return "High Energy" }
        if score >= 40 { return "Moderate" }
        return "Low Energy"
    }
    
    private var formattedDate: String {
        let f = DateFormatter()
        f.dateStyle = .long
        return f.string(from: Date())
    }
    
    // MARK: - Render card to UIImage
    func renderCard() -> UIImage {
        let renderer = ImageRenderer(content:
            shareCard
                .frame(width: 360)
                .environment(\.colorScheme, .dark)
        )
        renderer.scale = 3.0
        return renderer.uiImage ?? UIImage()
    }
}

// MARK: - UIActivityViewController wrapper
struct ShareSheet: UIViewControllerRepresentable {
    let items: [Any]
    
    func makeUIViewController(context: Context) -> UIActivityViewController {
        UIActivityViewController(activityItems: items, applicationActivities: nil)
    }
    
    func updateUIViewController(_ uvc: UIActivityViewController, context: Context) {}
}
