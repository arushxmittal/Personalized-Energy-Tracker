import SwiftUI

struct TipsView: View {

    let sleep: Double
    let stress: Double
    let focus: Double
    let mood: Double

    private var tips: [(label: String, tip: CategoryTip)] {
        [
            ("Sleep",  EnergyCalculator.sleepTip(for: sleep)),
            ("Stress", EnergyCalculator.stressTip(for: stress)),
            ("Focus",  EnergyCalculator.focusTip(for: focus)),
            ("Mood",   EnergyCalculator.moodTip(for: mood))
        ]
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 16) {

            Text("PERSONALIZED TIPS")
                .font(.caption)
                .fontWeight(.semibold)
                .foregroundColor(.purple)
                .padding(.horizontal, 4)

            ForEach(tips, id: \.label) { item in
                TipCard(label: item.label, tip: item.tip)
            }
        }
    }
}

// MARK: - TipCard
struct TipCard: View {

    let label: String
    let tip: CategoryTip

    @State private var expanded = false

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {

            // Header row — always visible
            Button(action: { withAnimation(.spring()) { expanded.toggle() } }) {
                HStack(spacing: 12) {

                    // Colored icon badge
                    ZStack {
                        Circle()
                            .fill(tip.swiftUIColor.opacity(0.2))
                            .frame(width: 38, height: 38)
                        Image(systemName: tip.icon)
                            .foregroundColor(tip.swiftUIColor)
                            .font(.system(size: 16, weight: .semibold))
                    }

                    VStack(alignment: .leading, spacing: 2) {
                        Text(label.uppercased())
                            .font(.caption2)
                            .foregroundColor(.white.opacity(0.5))
                        Text(tip.title)
                            .font(.subheadline)
                            .fontWeight(.semibold)
                            .foregroundColor(tip.swiftUIColor)
                    }

                    Spacer()

                    // Score pill
                    Image(systemName: expanded ? "chevron.up" : "chevron.down")
                        .font(.caption)
                        .foregroundColor(.white.opacity(0.4))
                }
            }
            .buttonStyle(.plain)

            // Expandable body
            if expanded {
                Text(tip.body)
                    .font(.subheadline)
                    .foregroundColor(.white.opacity(0.82))
                    .lineSpacing(4)
                    .transition(.opacity.combined(with: .move(edge: .top)))
            }
        }
        .padding()
        .background(.ultraThinMaterial)
        .cornerRadius(18)
        .overlay(
            RoundedRectangle(cornerRadius: 18)
                .stroke(tip.swiftUIColor.opacity(0.25), lineWidth: 1)
        )
        .shadow(color: tip.swiftUIColor.opacity(0.15), radius: 8)
    }
}
