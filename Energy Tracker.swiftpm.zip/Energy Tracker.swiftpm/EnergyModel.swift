import Foundation

struct EnergyEntry: Identifiable, Codable {
    var id = UUID()
    var date: Date
    var sleep: Double
    var stress: Double
    var focus: Double
    var mood: Double
    var score: Double
}
