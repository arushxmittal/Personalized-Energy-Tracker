import SwiftUI
import Charts

struct ResultView: View {

    let userName: String
    let sleep: Double
    let stress: Double
    let focus: Double
    let mood: Double
    let score: Double

    @ObservedObject var store: EnergyStore

    var body: some View {
        ZStack {
            background

            ScrollView {
                VStack(spacing: 25) {

                    Text("Your Energy Report, \(userName)")
                        .font(.title.bold())
                        .foregroundColor(.white)
                        .multilineTextAlignment(.center)

                    ProgressRing(score: score)

                    energyStatusLabel(score)

                    HStack(spacing: 10) {
                        Image(systemName: "lightbulb.fill")
                            .foregroundColor(.yellow)
                        Text(EnergyCalculator.suggestion(for: score))
                            .foregroundColor(.white.opacity(0.85))
                            .font(.subheadline)
                    }
                    .padding()
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(.ultraThinMaterial)
                    .cornerRadius(16)

                    statsGrid

                    TipsView(
                        sleep: sleep,
                        stress: stress,
                        focus: focus,
                        mood: mood
                    )

                    VStack(alignment: .leading, spacing: 8) {
                        Text("ENERGY HISTORY")
                            .font(.caption)
                            .fontWeight(.semibold)
                            .foregroundColor(.purple)
                        EnergyChartView(entries: store.entries)
                    }
                }
                .padding()
            }
        }
        .navigationBarTitleDisplayMode(.inline)
    }

    var statsGrid: some View {
        VStack(spacing: 10) {
            HStack(spacing: 10) {
                statCard("Sleep",  value: sleep,  icon: "bed.double.fill",  color: .blue)
                statCard("Stress", value: stress, icon: "flame.fill",        color: .orange)
            }
            HStack(spacing: 10) {
                statCard("Focus",  value: focus,  icon: "target",            color: .cyan)
                statCard("Mood",   value: mood,   icon: "face.smiling.fill", color: .pink)
            }
        }
    }

    func statCard(_ title: String,
                  value: Double,
                  icon: String,
                  color: Color) -> some View {
        VStack(spacing: 6) {
            Image(systemName: icon)
                .foregroundColor(color)
                .font(.title2)
            Text("\(Int(value))/10")
                .font(.title3.bold())
                .foregroundColor(.white)
            Text(title)
                .font(.caption)
                .foregroundColor(.white.opacity(0.6))
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 16)
        .background(.ultraThinMaterial)
        .cornerRadius(16)
        .overlay(
            RoundedRectangle(cornerRadius: 16)
                .stroke(color.opacity(0.3), lineWidth: 1)
        )
    }

    func energyStatusLabel(_ score: Double) -> some View {
        let text: String
        let color: Color

        if score >= 70 {
            text = "⚡ HIGH ENERGY"
            color = .green
        } else if score >= 40 {
            text = "〰 MODERATE ENERGY"
            color = .yellow
        } else {
            text = "🌙 LOW ENERGY — REST UP"
            color = .red
        }

        return Text(text)
            .font(.caption)
            .fontWeight(.semibold)
            .padding(.horizontal, 16)
            .padding(.vertical, 8)
            .background(color.opacity(0.2))
            .foregroundColor(color)
            .cornerRadius(20)
            .overlay(
                RoundedRectangle(cornerRadius: 20)
                    .stroke(color.opacity(0.4), lineWidth: 1)
            )
    }

    var background: some View {
        LinearGradient(
            colors: [Color.black,
                     Color.purple.opacity(0.7),
                     Color.blue.opacity(0.6)],
            startPoint: .topLeading,
            endPoint: .bottomTrailing
        )
        .ignoresSafeArea()
    }
}
