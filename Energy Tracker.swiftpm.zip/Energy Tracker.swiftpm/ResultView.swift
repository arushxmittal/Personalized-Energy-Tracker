import SwiftUI

struct ResultView: View {

    let userName: String
    let sleep: Double
    let stress: Double
    let focus: Double
    let mood: Double
    let score: Double

    @ObservedObject var store: EnergyStore
    @Binding var path: NavigationPath
    
    @State private var showShareCard = false
    @State private var showHistory = false
    @State private var newBadges: [Badge] = []
    @State private var showBadgeToast = false

    var body: some View {
        ZStack {
            background

            ScrollView {
                VStack(spacing: 25) {

                    Text("Your Energy Report, \(userName)")
                        .font(.title.bold())
                        .foregroundColor(.white)
                        .multilineTextAlignment(.center)

                    ProgressRing(score: score)

                    energyStatusLabel(score)

                    HStack(spacing: 10) {
                        Image(systemName: "lightbulb.fill")
                            .foregroundColor(.yellow)
                        Text(EnergyCalculator.suggestion(for: score))
                            .foregroundColor(.white.opacity(0.85))
                            .font(.subheadline)
                    }
                    .padding()
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(.ultraThinMaterial)
                    .cornerRadius(16)

                    statsGrid

                    ParticleEffectView(score: score)

                    TipsView(
                        sleep: sleep,
                        stress: stress,
                        focus: focus,
                        mood: mood
                    )

                    // MARK: - Action Buttons
                    VStack(spacing: 12) {
                        
                        // Share Card Button
                        Button(action: { showShareCard = true }) {
                            HStack(spacing: 10) {
                                Image(systemName: "square.and.arrow.up")
                                    .font(.subheadline.bold())
                                Text("Share My Energy Card")
                                    .font(.headline)
                            }
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(
                                LinearGradient(
                                    colors: [.purple, .blue],
                                    startPoint: .leading,
                                    endPoint: .trailing
                                )
                            )
                            .foregroundColor(.white)
                            .cornerRadius(16)
                            .shadow(color: .purple.opacity(0.5), radius: 10)
                        }
                        
                        // History Button
                        Button(action: { showHistory = true }) {
                            HStack(spacing: 10) {
                                Image(systemName: "clock.arrow.circlepath")
                                    .font(.subheadline.bold())
                                Text("View History & Badges")
                                    .font(.headline)
                            }
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(.ultraThinMaterial)
                            .foregroundColor(.white)
                            .cornerRadius(16)
                            .overlay(
                                RoundedRectangle(cornerRadius: 16)
                                    .stroke(Color.white.opacity(0.2), lineWidth: 1)
                            )
                        }
                        
                        // Start Over Button
                        Button(action: { path = NavigationPath() }) {
                            HStack(spacing: 10) {
                                Image(systemName: "arrow.counterclockwise")
                                    .font(.subheadline.bold())
                                Text("Start Over")
                                    .font(.headline)
                            }
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(Color.white.opacity(0.06))
                            .foregroundColor(.white.opacity(0.7))
                            .cornerRadius(16)
                            .overlay(
                                RoundedRectangle(cornerRadius: 16)
                                    .stroke(Color.white.opacity(0.1), lineWidth: 1)
                            )
                        }
                    }
                    .padding(.top, 8)
                    .padding(.bottom, 30)
                }
                .padding()
            }
            
            // MARK: - Badge Toast
            if showBadgeToast, let badge = newBadges.first {
                VStack {
                    Spacer()
                    HStack(spacing: 14) {
                        ZStack {
                            Circle()
                                .fill(badge.swiftUIColor.opacity(0.25))
                                .frame(width: 44, height: 44)
                            Image(systemName: badge.icon)
                                .foregroundColor(badge.swiftUIColor)
                                .font(.title3)
                        }
                        VStack(alignment: .leading, spacing: 2) {
                            Text("Badge Unlocked! 🎉")
                                .font(.caption)
                                .foregroundColor(.white.opacity(0.6))
                            Text(badge.title)
                                .font(.subheadline.bold())
                                .foregroundColor(.white)
                        }
                        Spacer()
                    }
                    .padding()
                    .background(.ultraThinMaterial)
                    .cornerRadius(18)
                    .overlay(
                        RoundedRectangle(cornerRadius: 18)
                            .stroke(badge.swiftUIColor.opacity(0.4), lineWidth: 1)
                    )
                    .shadow(color: badge.swiftUIColor.opacity(0.3), radius: 12)
                    .padding(.horizontal, 20)
                    .padding(.bottom, 30)
                    .transition(.move(edge: .bottom).combined(with: .opacity))
                }
                .animation(.spring(), value: showBadgeToast)
            }
        }
        .navigationBarTitleDisplayMode(.inline)
        .navigationBarBackButtonHidden(true)
        .sheet(isPresented: $showShareCard) {
            ShareCardView(
                userName: userName,
                sleep: sleep,
                stress: stress,
                focus: focus,
                mood: mood,
                score: score
            )
        }
        .sheet(isPresented: $showHistory) {
            NavigationStack {
                HistoryView(store: store)
            }
            .preferredColorScheme(.dark)
        }
        .onAppear {
            checkNewBadges()
        }
    }
    
    // MARK: - Check for newly unlocked badges
    func checkNewBadges() {
        let previousEntries = Array(store.entries.dropFirst())
        newBadges = store.newlyUnlockedBadges(before: previousEntries)
        if !newBadges.isEmpty {
            withAnimation(.spring()) { showBadgeToast = true }
            DispatchQueue.main.asyncAfter(deadline: .now() + 3.5) {
                withAnimation { showBadgeToast = false }
            }
        }
    }

    // MARK: - Stats Grid
    var statsGrid: some View {
        VStack(spacing: 10) {
            HStack(spacing: 10) {
                statCard("Sleep",  value: sleep,  icon: "bed.double.fill",  color: .blue)
                statCard("Stress", value: stress, icon: "flame.fill",        color: .orange)
            }
            HStack(spacing: 10) {
                statCard("Focus",  value: focus,  icon: "target",            color: .cyan)
                statCard("Mood",   value: mood,   icon: "face.smiling.fill", color: .pink)
            }
        }
    }

    func statCard(_ title: String,
                  value: Double,
                  icon: String,
                  color: Color) -> some View {
        VStack(spacing: 6) {
            Image(systemName: icon)
                .foregroundColor(color)
                .font(.title2)
            Text("\(Int(value))/10")
                .font(.title3.bold())
                .foregroundColor(.white)
            Text(title)
                .font(.caption)
                .foregroundColor(.white.opacity(0.6))
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 16)
        .background(.ultraThinMaterial)
        .cornerRadius(16)
        .overlay(
            RoundedRectangle(cornerRadius: 16)
                .stroke(color.opacity(0.3), lineWidth: 1)
        )
    }

    func energyStatusLabel(_ score: Double) -> some View {
        let text: String
        let color: Color
        if score >= 70 {
            text = "⚡ HIGH ENERGY"; color = .green
        } else if score >= 40 {
            text = "〰 MODERATE ENERGY"; color = .yellow
        } else {
            text = "🌙 LOW ENERGY — REST UP"; color = .red
        }
        return Text(text)
            .font(.caption)
            .fontWeight(.semibold)
            .padding(.horizontal, 16)
            .padding(.vertical, 8)
            .background(color.opacity(0.2))
            .foregroundColor(color)
            .cornerRadius(20)
            .overlay(RoundedRectangle(cornerRadius: 20).stroke(color.opacity(0.4), lineWidth: 1))
    }

    var background: some View {
        LinearGradient(
            colors: [Color.black, Color.purple.opacity(0.7), Color.blue.opacity(0.6)],
            startPoint: .topLeading,
            endPoint: .bottomTrailing
        )
        .ignoresSafeArea()
    }
}
