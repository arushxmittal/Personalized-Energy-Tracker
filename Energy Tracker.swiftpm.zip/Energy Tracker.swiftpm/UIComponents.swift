import SwiftUI

// MARK: - Glass Card
struct GlassCard: ViewModifier {
    func body(content: Content) -> some View {
        content
            .padding()
            .background(.ultraThinMaterial)
            .cornerRadius(22)
            .overlay(
                RoundedRectangle(cornerRadius: 22)
                    .stroke(Color.white.opacity(0.1), lineWidth: 1)
            )
            .shadow(color: .purple.opacity(0.3), radius: 12)
    }
}

extension View {
    func glassCard() -> some View {
        modifier(GlassCard())
    }
}

// MARK: - Progress Ring
struct ProgressRing: View {

    var score: Double

    private var ringColor: Color {
        if score >= 70 { return .green }
        if score >= 40 { return .yellow }
        return .red
    }

    var body: some View {
        ZStack {
            Circle()
                .stroke(Color.white.opacity(0.2), lineWidth: 20)

            Circle()
                .trim(from: 0, to: score / 100)
                .stroke(
                    ringColor,
                    style: StrokeStyle(lineWidth: 20, lineCap: .round)
                )
                .rotationEffect(.degrees(-90))
                .animation(.easeOut(duration: 1.0), value: score)

            VStack(spacing: 4) {
                Text("\(Int(score))%")
                    .font(.largeTitle.bold())
                    .foregroundColor(.white)
                Text("Energy")
                    .font(.caption)
                    .foregroundColor(.white.opacity(0.5))
            }
        }
        .frame(width: 200, height: 200)
    }
}

// MARK: - Particle Model
struct Particle: Identifiable {
    let id = UUID()
    var x: CGFloat
    var y: CGFloat
    var size: CGFloat
    var opacity: Double
    var speed: Double
    var angle: Double
    var color: Color
}

// MARK: - Particle Effect View
struct ParticleEffectView: View {

    let score: Double

    @State private var particles: [Particle] = []
    @State private var animating = false
    @State private var timer: Timer? = nil

    // MARK: Computed properties based on score
    private var particleCount: Int {
        if score >= 70 { return 60 }
        if score >= 40 { return 35 }
        return 18
    }

    private var particleColors: [Color] {
        if score >= 70 {
            return [.green, .cyan, .yellow, .white]
        } else if score >= 40 {
            return [.yellow, .orange, .white, .purple]
        } else {
            return [.blue, .purple, .indigo, .white.opacity(0.6)]
        }
    }

    private var speedMultiplier: Double {
        if score >= 70 { return 1.4 }
        if score >= 40 { return 0.9 }
        return 0.5
    }

    private var orbColor: Color {
        if score >= 70 { return .green }
        if score >= 40 { return .yellow }
        return .indigo
    }

    private var labelText: String {
        if score >= 70 { return "⚡ High Energy Field" }
        if score >= 40 { return "〰 Moderate Energy Field" }
        return "🌙 Low Energy Field"
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {

            Text("ENERGY FIELD")
                .font(.caption)
                .fontWeight(.semibold)
                .foregroundColor(.purple)
                .padding(.horizontal, 4)

            ZStack {

                // Background card
                RoundedRectangle(cornerRadius: 24)
                    .fill(Color.black.opacity(0.4))
                    .overlay(
                        RoundedRectangle(cornerRadius: 24)
                            .stroke(orbColor.opacity(0.3), lineWidth: 1)
                    )

                // Particles
                ForEach(particles) { particle in
                    Circle()
                        .fill(particle.color)
                        .frame(width: particle.size, height: particle.size)
                        .opacity(particle.opacity)
                        .position(x: particle.x, y: particle.y)
                        .blur(radius: particle.size > 5 ? 1.5 : 0.5)
                }

                // Center orb with pulsing rings
                ZStack {
                    ForEach(0..<3) { i in
                        Circle()
                            .stroke(orbColor.opacity(0.15 - Double(i) * 0.04), lineWidth: 1)
                            .frame(
                                width: animating ? CGFloat(70 + i * 28) : CGFloat(60 + i * 22),
                                height: animating ? CGFloat(70 + i * 28) : CGFloat(60 + i * 22)
                            )
                            .animation(
                                .easeInOut(duration: 1.6 + Double(i) * 0.4)
                                .repeatForever(autoreverses: true),
                                value: animating
                            )
                    }

                    // Core orb
                    Circle()
                        .fill(
                            RadialGradient(
                                colors: [orbColor, orbColor.opacity(0.3)],
                                center: .center,
                                startRadius: 0,
                                endRadius: 30
                            )
                        )
                        .frame(
                            width: animating ? 58 : 48,
                            height: animating ? 58 : 48
                        )
                        .shadow(color: orbColor.opacity(0.8), radius: animating ? 20 : 10)
                        .animation(
                            .easeInOut(duration: 1.2).repeatForever(autoreverses: true),
                            value: animating
                        )

                    // Score inside orb
                    Text("\(Int(score))")
                        .font(.system(size: 18, weight: .bold))
                        .foregroundColor(.white)
                }

                // Bottom label
                VStack {
                    Spacer()
                    Text(labelText)
                        .font(.caption)
                        .fontWeight(.medium)
                        .foregroundColor(orbColor)
                        .padding(.bottom, 14)
                }
            }
            .frame(height: 260)
            .clipShape(RoundedRectangle(cornerRadius: 24))
            .shadow(color: orbColor.opacity(0.3), radius: 16)
        }
        .onAppear {
            spawnParticles()
            animating = true
            startParticleAnimation()
        }
        .onDisappear {
            timer?.invalidate()
            timer = nil
        }
    }

    // MARK: - Spawn particles
    func spawnParticles() {
        particles = (0..<particleCount).map { _ in makeParticle() }
    }

    func makeParticle() -> Particle {
        Particle(
            x: CGFloat.random(in: 20...340),
            y: CGFloat.random(in: 20...240),
            size: CGFloat.random(in: 2...9),
            opacity: Double.random(in: 0.4...1.0),
            speed: Double.random(in: 0.8...2.2) * speedMultiplier,
            angle: Double.random(in: 0...(2 * .pi)),
            color: particleColors.randomElement() ?? .white
        )
    }

    // MARK: - Animate particles
    func startParticleAnimation() {
        timer = Timer.scheduledTimer(withTimeInterval: 0.05, repeats: true) { _ in
            withAnimation(.linear(duration: 0.05)) {
                for i in particles.indices {
                    let dx = cos(particles[i].angle) * particles[i].speed
                    let dy = sin(particles[i].angle) * particles[i].speed

                    particles[i].x += dx
                    particles[i].y += dy

                    let margin: CGFloat = 15
                    if particles[i].x < margin || particles[i].x > 345 ||
                       particles[i].y < margin || particles[i].y > 245 {
                        particles[i] = makeParticle()
                    }

                    if Double.random(in: 0...1) < 0.08 {
                        particles[i].opacity = Double.random(in: 0.3...1.0)
                    }
                }
            }
        }
    }
}
