//
//  SwiftUIView.swift
//  Energy Tracker
//
//  Created by Chirag Dawra on 26/02/26.
//

import SwiftUI

struct SwiftUIView: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

#Preview {
    SwiftUIView()
}
