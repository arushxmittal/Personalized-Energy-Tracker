import SwiftUI
import Charts

struct EnergyChartView: View {
    
    var entries: [EnergyEntry]
    
    var body: some View {
        Chart(entries) { entry in
            BarMark(
                x: .value("Date", entry.date, unit: .day),
                y: .value("Score", entry.score)
            )
        }
        .frame(height: 200)
    }
}
