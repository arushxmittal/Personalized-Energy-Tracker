import SwiftUI

struct LoginView: View {
    
    @State private var name = ""
    
    var body: some View {
        ZStack {
            background
            
            VStack(spacing: 30) {
                
                Text("Pulse")
                    .font(.system(size: 42, weight: .bold))
                
                Text("Enter Your Name")
                    .foregroundColor(.white.opacity(0.7))
                
                TextField("Your Name", text: $name)
                    .padding()
                    .background(Color.white.opacity(0.1))
                    .cornerRadius(12)
                    .foregroundColor(.white)
                
                NavigationLink(
                    destination: InputView(userName: name),
                    isActive: .constant(!name.isEmpty)  
                ) {
                    EmptyView()
                }
                
                NavigationLink(destination: InputView(userName: name)) {
                    Text("Continue")
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(
                            LinearGradient(
                                colors: [.purple, .blue],
                                startPoint: .leading,
                                endPoint: .trailing
                            )
                        )
                        .cornerRadius(16)
                }
                .disabled(name.isEmpty)
            }
            .padding()
        }
    }
    
    var background: some View {
        LinearGradient(
            colors: [Color.black,
                     Color.purple.opacity(0.7),
                     Color.blue.opacity(0.6)],
            startPoint: .topLeading,
            endPoint: .bottomTrailing
        )
        .ignoresSafeArea()
    }
}
