import SwiftUI

struct LoginView: View {

    @Binding var path: NavigationPath
    @State private var name = ""

    var body: some View {
        ZStack {
            background

            VStack(spacing: 30) {

                Text("Pulse")
                    .font(.system(size: 42, weight: .bold))
                    .foregroundColor(.white)

                Text("Enter Your Name")
                    .foregroundColor(.white.opacity(0.7))

                TextField("Your Name", text: $name)
                    .padding()
                    .background(Color.white.opacity(0.1))
                    .cornerRadius(12)
                    .foregroundColor(.white)

                Button(action: {
                    if !name.isEmpty {
                        path.append(name)
                    }
                }) {
                    Text("Continue")
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(
                            LinearGradient(
                                colors: [.purple, .blue],
                                startPoint: .leading,
                                endPoint: .trailing
                            )
                        )
                        .cornerRadius(16)
                        .foregroundColor(.white)
                        .opacity(name.isEmpty ? 0.5 : 1.0)
                }
                .disabled(name.isEmpty)
            }
            .padding()
        }
        .navigationDestination(for: String.self) { userName in
            InputView(userName: userName, path: $path)
        }
    }

    var background: some View {
        LinearGradient(
            colors: [Color.black,
                     Color.purple.opacity(0.7),
                     Color.blue.opacity(0.6)],
            startPoint: .topLeading,
            endPoint: .bottomTrailing
        )
        .ignoresSafeArea()
    }
}
