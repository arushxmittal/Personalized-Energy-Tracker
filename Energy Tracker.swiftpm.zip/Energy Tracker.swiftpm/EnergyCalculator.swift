import Foundation

struct EnergyCalculator {

    static func calculate(
        sleep: Double,
        stress: Double,
        focus: Double,
        mood: Double
    ) -> Double {
        return round(
            (sleep * 0.3 +
             (10 - stress) * 0.25 +
             focus * 0.25 +
             mood * 0.2) * 10
        )
    }

    static func suggestion(for score: Double) -> String {
        if score >= 70 {
            return "🔥 Peak state detected. Tackle your hardest task NOW."
        }
        if score >= 40 {
            return "🧘 Take a short reset break and hydrate."
        }
        return "🌙 Low recovery detected. Prioritize rest."
    }

    // MARK: - Sleep Tips
    static func sleepTip(for value: Double) -> CategoryTip {
        switch value {
        case 1...3:
            return CategoryTip(
                icon: "bed.double.fill",
                color: "red",
                title: "Critically Low Sleep",
                body: "You're severely sleep deprived. Your reaction time, memory, and mood are all impaired. Avoid caffeine after 2pm, set a firm bedtime tonight, and aim for at least 7 hours. Consider a 20-minute nap today if possible."
            )
        case 4...5:
            return CategoryTip(
                icon: "bed.double.fill",
                color: "orange",
                title: "Below Average Sleep",
                body: "You're running on less than ideal rest. Try going to bed 30 minutes earlier tonight. Avoid screens 1 hour before sleep and keep your room cool and dark. Consistency in wake time matters more than sleep time."
            )
        case 6...7:
            return CategoryTip(
                icon: "bed.double.fill",
                color: "yellow",
                title: "Decent Sleep",
                body: "You're getting a reasonable amount of sleep. To improve quality, try a short wind-down routine — light stretching or reading. Avoid heavy meals close to bedtime to deepen your sleep cycles."
            )
        case 8...9:
            return CategoryTip(
                icon: "bed.double.fill",
                color: "green",
                title: "Good Sleep",
                body: "Your sleep is solid. Keep your schedule consistent even on weekends. If you feel groggy despite good hours, check for sleep quality issues like noise or light disturbances."
            )
        default:
            return CategoryTip(
                icon: "bed.double.fill",
                color: "green",
                title: "Excellent Sleep",
                body: "You're fully rested. Your body has had time to repair and consolidate memory. Maintain this by sticking to your current sleep schedule — it's clearly working well for you."
            )
        }
    }

    // MARK: - Stress Tips
    static func stressTip(for value: Double) -> CategoryTip {
        switch value {
        case 1...3:
            return CategoryTip(
                icon: "flame.fill",
                color: "green",
                title: "Low Stress",
                body: "Your stress is well managed today. This is a great state to tackle deep work or creative tasks. Use this calm window to plan ahead and reduce future stressors proactively."
            )
        case 4...6:
            return CategoryTip(
                icon: "flame.fill",
                color: "yellow",
                title: "Moderate Stress",
                body: "You're feeling some pressure. Try box breathing (inhale 4s, hold 4s, exhale 4s, hold 4s) for 2 minutes. A short walk outside can lower cortisol significantly. Break large tasks into smaller steps to feel more in control."
            )
        case 7...8:
            return CategoryTip(
                icon: "flame.fill",
                color: "orange",
                title: "High Stress",
                body: "Your stress is elevated and likely affecting your focus and mood. Step away from screens for 10 minutes. Talk to someone you trust, or write down what's on your mind. Prioritize only the top 1-2 tasks for today."
            )
        default:
            return CategoryTip(
                icon: "flame.fill",
                color: "red",
                title: "Very High Stress",
                body: "You're in a high-stress state. This level of stress is harmful if sustained. Take an immediate break — even 5 minutes of slow breathing helps. Consider what's driving this stress and whether any tasks can be delegated or postponed today."
            )
        }
    }

    // MARK: - Focus Tips
    static func focusTip(for value: Double) -> CategoryTip {
        switch value {
        case 1...3:
            return CategoryTip(
                icon: "target",
                color: "red",
                title: "Very Low Focus",
                body: "Concentration is very difficult right now. Avoid multitasking entirely. Use the Pomodoro method — 25 minutes of single-task work, then a 5-minute break. Remove all phone notifications and work in the quietest space available."
            )
        case 4...5:
            return CategoryTip(
                icon: "target",
                color: "orange",
                title: "Below Average Focus",
                body: "You're struggling to stay on task. Start with your easiest pending task to build momentum. Make sure you're hydrated — even mild dehydration reduces concentration. Close unnecessary browser tabs and apps."
            )
        case 6...7:
            return CategoryTip(
                icon: "target",
                color: "yellow",
                title: "Moderate Focus",
                body: "Your focus is functional but not peak. Use this window for medium-complexity work. Batch similar tasks together to reduce cognitive switching. A short stretch break every 45 minutes can help sustain this level."
            )
        case 8...9:
            return CategoryTip(
                icon: "target",
                color: "green",
                title: "Strong Focus",
                body: "You're in a solid focused state. Use this for your most important or complex work. Protect this window — let others know you're in deep work mode and minimize interruptions."
            )
        default:
            return CategoryTip(
                icon: "target",
                color: "green",
                title: "Peak Focus",
                body: "You're in flow state territory. Tackle your hardest, highest-value task right now. This level of focus is rare — don't waste it on emails or admin. Block out everything and go deep."
            )
        }
    }

    // MARK: - Mood Tips
    static func moodTip(for value: Double) -> CategoryTip {
        switch value {
        case 1...3:
            return CategoryTip(
                icon: "face.smiling.fill",
                color: "red",
                title: "Low Mood",
                body: "You're feeling quite low today. Be gentle with yourself — don't set unrealistic expectations. Do one small thing that usually brings you joy. Sunlight and movement, even a 10-minute walk, can meaningfully shift your mood chemistry."
            )
        case 4...5:
            return CategoryTip(
                icon: "face.smiling.fill",
                color: "orange",
                title: "Below Average Mood",
                body: "Your mood is dragging a bit. Try connecting with a friend or colleague, even briefly. Gratitude journaling — writing 3 specific things you're thankful for — has been shown to lift mood within minutes."
            )
        case 6...7:
            return CategoryTip(
                icon: "face.smiling.fill",
                color: "yellow",
                title: "Neutral Mood",
                body: "You're feeling okay but not great. This is a good baseline to build on. Physical activity, music you enjoy, or a small act of kindness can nudge your mood upward and keep your energy steady through the day."
            )
        case 8...9:
            return CategoryTip(
                icon: "face.smiling.fill",
                color: "green",
                title: "Good Mood",
                body: "You're in a positive headspace. Good mood enhances creativity and social interaction. Use this state for collaboration, brainstorming, or any task that benefits from enthusiasm and openness."
            )
        default:
            return CategoryTip(
                icon: "face.smiling.fill",
                color: "green",
                title: "Excellent Mood",
                body: "You're feeling great! Your positive state is contagious and productive. Channel this into meaningful work or helping someone around you. Also a perfect time to tackle something you've been putting off."
            )
        }
    }
}

// MARK: - CategoryTip Model
struct CategoryTip {
    let icon: String
    let color: String
    let title: String
    let body: String

    var swiftUIColor: Color {
        switch color {
        case "red":    return .red
        case "orange": return .orange
        case "yellow": return .yellow
        case "green":  return .green
        default:       return .purple
        }
    }
}

import SwiftUI
