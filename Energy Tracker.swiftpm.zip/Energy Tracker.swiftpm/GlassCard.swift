import SwiftUI

struct GlassCard: ViewModifier {
    func body(content: Content) -> some View {
        content
            .padding()
            .background(.ultraThinMaterial)
            .cornerRadius(22)
            .overlay(
                RoundedRectangle(cornerRadius: 22)
                    .stroke(Color.white.opacity(0.1), lineWidth: 1)
            )
            .shadow(color: .purple.opacity(0.3), radius: 12)
    }
}

extension View {
    func glassCard() -> some View {
        modifier(GlassCard())
    }
}
