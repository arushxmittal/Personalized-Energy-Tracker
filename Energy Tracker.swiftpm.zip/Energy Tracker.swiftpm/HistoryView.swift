import SwiftUI

struct HistoryView: View {
    
    @ObservedObject var store: EnergyStore
    
    var body: some View {
        ZStack {
            background
            
            ScrollView {
                VStack(spacing: 20) {
                    
                    // MARK: - Streak Banner
                    streakBanner
                    
                    // MARK: - Badges Section
                    if !store.unlockedBadges.isEmpty {
                        badgesSection
                    }
                    
                    // MARK: - History List
                    historySection
                }
                .padding()
            }
        }
        .navigationTitle("History")
        .navigationBarTitleDisplayMode(.inline)
    }
    
    // MARK: - Streak Banner
    var streakBanner: some View {
        HStack(spacing: 16) {
            ZStack {
                Circle()
                    .fill(Color.orange.opacity(0.2))
                    .frame(width: 56, height: 56)
                Image(systemName: "flame.fill")
                    .foregroundColor(.orange)
                    .font(.title2)
            }
            VStack(alignment: .leading, spacing: 4) {
                Text("\(store.currentStreak) Day Streak")
                    .font(.title3.bold())
                    .foregroundColor(.white)
                Text(store.currentStreak == 0 ? "Log today to start your streak!" : "Keep it going!")
                    .font(.caption)
                    .foregroundColor(.white.opacity(0.6))
            }
            Spacer()
            Text("🔥")
                .font(.largeTitle)
        }
        .padding()
        .background(.ultraThinMaterial)
        .cornerRadius(20)
        .overlay(
            RoundedRectangle(cornerRadius: 20)
                .stroke(Color.orange.opacity(0.3), lineWidth: 1)
        )
    }
    
    // MARK: - Badges Section
    var badgesSection: some View {
        VStack(alignment: .leading, spacing: 14) {
            
            Text("BADGES")
                .font(.caption)
                .fontWeight(.semibold)
                .foregroundColor(.purple)
                .padding(.horizontal, 4)
            
            LazyVGrid(columns: [
                GridItem(.flexible()),
                GridItem(.flexible()),
                GridItem(.flexible())
            ], spacing: 12) {
                ForEach(store.unlockedBadges) { badge in
                    BadgeCard(badge: badge)
                }
            }
        }
    }
    
    // MARK: - History Section
    var historySection: some View {
        VStack(alignment: .leading, spacing: 14) {
            
            Text("PAST ENTRIES")
                .font(.caption)
                .fontWeight(.semibold)
                .foregroundColor(.purple)
                .padding(.horizontal, 4)
            
            if store.entries.isEmpty {
                VStack(spacing: 12) {
                    Image(systemName: "tray")
                        .font(.system(size: 40))
                        .foregroundColor(.white.opacity(0.3))
                    Text("No entries yet.\nLog your first energy score!")
                        .font(.subheadline)
                        .foregroundColor(.white.opacity(0.4))
                        .multilineTextAlignment(.center)
                }
                .frame(maxWidth: .infinity)
                .padding(40)
            } else {
                ForEach(store.entries) { entry in
                    HistoryCard(entry: entry)
                }
            }
        }
    }
    
    var background: some View {
        LinearGradient(
            colors: [Color.black,
                     Color.purple.opacity(0.7),
                     Color.blue.opacity(0.6)],
            startPoint: .topLeading,
            endPoint: .bottomTrailing
        )
        .ignoresSafeArea()
    }
}

// MARK: - Badge Card
struct BadgeCard: View {
    let badge: Badge
    
    var body: some View {
        VStack(spacing: 8) {
            ZStack {
                Circle()
                    .fill(badge.swiftUIColor.opacity(0.2))
                    .frame(width: 52, height: 52)
                Image(systemName: badge.icon)
                    .foregroundColor(badge.swiftUIColor)
                    .font(.title3)
            }
            Text(badge.title)
                .font(.caption2)
                .fontWeight(.semibold)
                .foregroundColor(.white)
                .multilineTextAlignment(.center)
                .lineLimit(2)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 14)
        .background(.ultraThinMaterial)
        .cornerRadius(16)
        .overlay(
            RoundedRectangle(cornerRadius: 16)
                .stroke(badge.swiftUIColor.opacity(0.3), lineWidth: 1)
        )
        .shadow(color: badge.swiftUIColor.opacity(0.2), radius: 8)
    }
}

// MARK: - History Card
struct HistoryCard: View {
    let entry: EnergyEntry
    
    private var scoreColor: Color {
        if entry.score >= 70 { return .green }
        if entry.score >= 40 { return .yellow }
        return .red
    }
    
    private var scoreLabel: String {
        if entry.score >= 70 { return "High" }
        if entry.score >= 40 { return "Moderate" }
        return "Low"
    }
    
    private var formattedDate: String {
        let f = DateFormatter()
        f.dateStyle = .medium
        f.timeStyle = .short
        return f.string(from: entry.date)
    }
    
    var body: some View {
        HStack(spacing: 14) {
            
            // Score circle
            ZStack {
                Circle()
                    .stroke(scoreColor.opacity(0.3), lineWidth: 3)
                    .frame(width: 52, height: 52)
                Text("\(Int(entry.score))")
                    .font(.system(size: 15, weight: .bold))
                    .foregroundColor(scoreColor)
            }
            
            VStack(alignment: .leading, spacing: 4) {
                Text(formattedDate)
                    .font(.subheadline)
                    .fontWeight(.semibold)
                    .foregroundColor(.white)
                HStack(spacing: 10) {
                    statPill("💤", "\(Int(entry.sleep))")
                    statPill("🔥", "\(Int(entry.stress))")
                    statPill("🎯", "\(Int(entry.focus))")
                    statPill("😊", "\(Int(entry.mood))")
                }
            }
            
            Spacer()
            
            Text(scoreLabel)
                .font(.caption2)
                .fontWeight(.bold)
                .padding(.horizontal, 10)
                .padding(.vertical, 5)
                .background(scoreColor.opacity(0.2))
                .foregroundColor(scoreColor)
                .cornerRadius(10)
        }
        .padding()
        .background(.ultraThinMaterial)
        .cornerRadius(16)
        .overlay(
            RoundedRectangle(cornerRadius: 16)
                .stroke(scoreColor.opacity(0.15), lineWidth: 1)
        )
    }
    
    func statPill(_ emoji: String, _ value: String) -> some View {
        HStack(spacing: 3) {
            Text(emoji).font(.caption2)
            Text(value)
                .font(.caption2)
                .fontWeight(.medium)
                .foregroundColor(.white.opacity(0.7))
        }
    }
}
