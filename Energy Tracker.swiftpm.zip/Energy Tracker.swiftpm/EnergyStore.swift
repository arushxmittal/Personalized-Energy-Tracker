import Foundation

class EnergyStore: ObservableObject {
    
    @Published var entries: [EnergyEntry] = [] {
        didSet { save() }
    }
    
    private let key = "energy_entries"
    
    init() { load() }
    
    func add(entry: EnergyEntry) {
        entries.insert(entry, at: 0)
    }
    
    // MARK: - Persistence
    private func save() {
        if let data = try? JSONEncoder().encode(entries) {
            UserDefaults.standard.set(data, forKey: key)
        }
    }
    
    private func load() {
        if let data = UserDefaults.standard.data(forKey: key),
           let saved = try? JSONDecoder().decode([EnergyEntry].self, from: data) {
            entries = saved
        }
    }
    
    // MARK: - Streak
    var currentStreak: Int {
        guard !entries.isEmpty else { return 0 }
        let calendar = Calendar.current
        var streak = 1
        let sorted = entries.sorted { $0.date > $1.date }
        for i in 1..<sorted.count {
            let prev = sorted[i - 1].date
            let curr = sorted[i].date
            if calendar.isDate(curr, inSameDayAs: calendar.date(byAdding: .day, value: -1, to: prev)!) {
                streak += 1
            } else {
                break
            }
        }
        return streak
    }
    
    // MARK: - Badges
    var unlockedBadges: [Badge] {
        var badges: [Badge] = []
        
        if entries.count >= 1 {
            badges.append(Badge(id: "first_entry", icon: "star.fill", title: "First Entry", description: "Logged your first score", color: "yellow"))
        }
        if currentStreak >= 3 {
            badges.append(Badge(id: "streak_3", icon: "flame.fill", title: "3 Day Streak", description: "Logged 3 days in a row", color: "orange"))
        }
        if entries.contains(where: { $0.score >= 70 }) {
            badges.append(Badge(id: "high_flyer", icon: "bolt.fill", title: "High Flyer", description: "Scored 70+ for the first time", color: "green"))
        }
        if entries.count >= 7 {
            badges.append(Badge(id: "perfect_week", icon: "calendar.badge.checkmark", title: "Perfect Week", description: "Logged 7 entries", color: "blue"))
        }
        if entries.contains(where: { $0.stress <= 3 }) {
            badges.append(Badge(id: "zen_master", icon: "leaf.fill", title: "Zen Master", description: "Stress below 3", color: "mint"))
        }
        if entries.contains(where: { $0.sleep >= 8 }) {
            badges.append(Badge(id: "sleep_champ", icon: "bed.double.fill", title: "Sleep Champion", description: "Sleep score above 8", color: "purple"))
        }
        
        return badges
    }
    
    // MARK: - Newly unlocked badge (after latest entry)
    func newlyUnlockedBadges(before: [EnergyEntry]) -> [Badge] {
        let oldStore = EnergyStore()
        oldStore.entries = before
        let oldIds = Set(oldStore.unlockedBadges.map { $0.id })
        return unlockedBadges.filter { !oldIds.contains($0.id) }
    }
}

// MARK: - Badge Model
struct Badge: Identifiable, Equatable {
    let id: String
    let icon: String
    let title: String
    let description: String
    let color: String
    
    var swiftUIColor: Color {
        switch color {
        case "yellow":  return .yellow
        case "orange":  return .orange
        case "green":   return .green
        case "blue":    return .blue
        case "mint":    return .mint
        case "purple":  return .purple
        default:        return .white
        }
    }
}

import SwiftUI
