import Foundation

class EnergyStore: ObservableObject {
    
    @Published var entries: [EnergyEntry] = []
    
    func add(entry: EnergyEntry) {
        entries.insert(entry, at: 0)
    }
}
